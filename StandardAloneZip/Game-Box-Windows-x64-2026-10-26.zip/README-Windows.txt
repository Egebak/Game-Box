Game Box for Windows x64

Extract the entire ZIP to one folder, then double-click Game Box.exe.
Keep Game Box.pck and data_GameBox_windows_x86_64 beside the executable.
The Godot editor and .NET SDK are not required to play this standalone build.

Built from Game-Box commit d272e81 with Godot 4.6.3 .NET.
